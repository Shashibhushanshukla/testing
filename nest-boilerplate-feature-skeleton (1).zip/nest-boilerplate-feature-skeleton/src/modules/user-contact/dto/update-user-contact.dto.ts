import { IsEmail, isEmail, IsNotEmpty } from "class-validator";


export class UpdateUserContactDto
{
  
  
  phone?: string;

  address?: string;

  
  status?: string;


}
