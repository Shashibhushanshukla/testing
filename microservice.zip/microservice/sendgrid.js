const sgMail = require('@sendgrid/mail')
//sgMail.setApiKey(process.env.SENDGRID_API_KEY)
sgMail.setApiKey("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")
const msg = {
  to: 'shashi.bhushan@successive.tech', // Change to your recipient
  from: 'shashi.bhushan@successive.tech', // Change to your verified sender
  subject: 'Sending with SendGrid is Fun',
  text: 'and easy to do anywhere, even with Node.js',
  html: '<strong>and easy to do anywhere, even with Node.js</strong>',
}
let test=''; 
 sgMail
  .send(msg)
  .then(() => {
    console.log("Email send");
  })
  .catch((error) => {
    console.error(error)
  })

  ;