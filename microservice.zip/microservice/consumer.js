//const Kafka = require("kafkajs").Kafka
const {Kafka} = require("kafkajs")

run();
async function run(){
    try
    {
         const kafka = new Kafka({
              "clientId": "myapp1",
              "brokers" :["localhost:9092"]
         })

        const consumer = kafka.consumer({"groupId": "test"})
        console.log("Connecting.....")
        await consumer.connect()
        console.log("Connected!")
        
        await consumer.subscribe({
            "topic": "Users",
            "fromBeginning": true
        })
        
        await consumer.run({
            "eachMessage": async result => {
                //1) Notification Type
                //2) Load template
                //3) Replace variables
                //4) Call sendgrid
                //5) Return response to upper level

                console.log(`RVD Msg ${result.message.value} on partition ${result.partition}`)
                // Sendgrid 2 //
                // Proccesed 3 //
            
            }
        })
 

    }
    catch(ex)
    {
        console.error(`Something bad happened ${ex}`)
    }
    finally{
        
    }


}